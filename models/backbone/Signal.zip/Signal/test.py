import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional

class BiLevelRoutingAttention(nn.Module):
    def __init__(self, dim, num_heads=8, n_win=7, qk_scale=None, topk=4, side_dwconv=3, auto_pad=False, attn_backend='torch'):
        super().__init__()

        self.dim = dim
        self.num_heads = num_heads
        assert self.dim % num_heads == 0, 'dim must be divisible by num_heads!'
        self.head_dim = self.dim // self.num_heads
        self.scale = qk_scale or self.dim ** -0.5

        # Define any other initialization parameters as needed

        # 侧面深度卷积，用于局部上下文增强
        self.lepe = nn.Conv1d(dim, dim, kernel_size=side_dwconv, stride=1, padding=side_dwconv // 2,
                              groups=dim) if side_dwconv > 0 else \
            lambda x: torch.zeros_like(x)

        self.topk = topk
        self.n_win = n_win

        # 线性层用于生成查询（q）、键（k）和值（v）
        self.qkv_linear = nn.Conv1d(self.dim, 3 * self.dim, kernel_size=1)
        self.output_linear = nn.Conv1d(self.dim, self.dim, kernel_size=1)
        # 选择后端实现注意力机制
        if attn_backend == 'torch':
            self.attn_fn = regional_routing_attention_torch
        else:
            raise ValueError('CUDA implementation is not available yet. Please stay tuned.')

    def forward(self, x: torch.Tensor, ret_attn_mask=False) -> torch.Tensor:
        N, L, C = x.size()  # Input shape: (batch_size, sequence_length, features)
        region_size = (L // self.n_win)

        # 第一步：线性投影到q、k、v空间
        qkv = self.qkv_linear.forward(x.permute(0, 2, 1))  # ncL
        q, k, v = qkv.chunk(3, dim=1)  # ncL

        # 第二步：区域到区域路由
        q_r = F.avg_pool1d(q.detach(), kernel_size=region_size, ceil_mode=True, count_include_pad=False)
        k_r = F.avg_pool1d(k.detach(), kernel_size=region_size, ceil_mode=True, count_include_pad=False)  # nchw
        q_r: torch.Tensor = q_r.permute(0, 2, 1).flatten(1, 2)  # n(hw)c
        k_r: torch.Tensor = k_r.flatten(2)  # nc(hw)
        a_r = q_r @ k_r  # n(hw)(hw), adj matrix of regional graph
        _, idx_r = torch.topk(a_r, k=self.topk, dim=-1)  # n(hw)k long tensor
        idx_r: torch.LongTensor = idx_r.unsqueeze_(1).expand(-1, self.num_heads, -1, -1)

        # 第三步：非参数化的token-to-token注意力
        output, attn_mat = self.attn_fn(query=q, key=k, value=v, scale=self.scale,
                                        region_graph=idx_r, region_size=region_size
                                        )

        output = output + self.lepe(v.permute(0, 2, 1))  # ncL
        output = self.output_linear(output.permute(0, 2, 1))  # ncL

        if ret_attn_mask:
            return output, attn_mat

        return output

def regional_routing_attention_torch(
        query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, scale: float,
        region_graph: torch.LongTensor, region_size: Tuple[int],
        kv_region_size: Optional[Tuple[int]] = None,
        auto_pad=True) -> torch.Tensor:
    kv_region_size = kv_region_size or region_size
    bs, nhead, q_nregion, topk = region_graph.size()

    q_pad_b, q_pad_r, kv_pad_b, kv_pad_r = 0, 0, 0, 0
    if auto_pad:
        _, _, Lq = query.size()
        q_pad_b = (region_size - Lq % region_size) % region_size
        if q_pad_b > 0:
            query = F.pad(query, (0, q_pad_r))

    query, q_region_h, q_region_w = _grid2seq(query, region_size=region_size, num_heads=nhead)
    key, _, _ = _grid2seq(key, region_size=kv_region_size, num_heads=nhead)
    value, _, _ = _grid2seq(value, region_size=kv_region_size, num_heads=nhead)

    bs, nhead, kv_nregion, kv_region_size, head_dim = key.size()
    broadcasted_region_graph = region_graph.view(bs, nhead, q_nregion, topk, 1, 1). \
        expand(-1, -1, -1, -1, kv_region_size, head_dim)
    key_g = torch.gather(key.view(bs, nhead, 1, kv_nregion, kv_region_size, head_dim). \
                         expand(-1, -1, query.size(2), -1, -1, -1), dim=3,
                         index=broadcasted_region_graph)  # (bs, nhead, q_nregion, topk, kv_region_size, head_dim)
    value_g = torch.gather(value.view(bs, nhead, 1, kv_nregion, kv_region_size, head_dim). \
                           expand(-1, -1, query.size(2), -1, -1, -1), dim=3,
                           index=broadcasted_region_graph)  # (bs, nhead, q_nregion, topk, kv_region_size, head_dim)

    attn = (query * scale) @ key_g.flatten(-3, -2).transpose(-1, -2)
    attn = torch.softmax(attn, dim=-1)

    output = attn @ value_g.flatten(-3, -2)

    output = _seq2grid(output, region_h=q_region_h, region_w=q_region_w, region_size=region_size)

    if auto_pad and q_pad_b > 0:
        output = output[:, :, :Lq]

    return output, attn

def _grid2seq(x: torch.Tensor, region_size: Tuple[int], num_heads: int):
    B, L, C = x.size()
    region_h = L // region_size
    x = x.view(B, num_heads, C // num_heads, region_h, region_size)
    x = torch.einsum('bmdhpwq->bmhwpqd', x).flatten(2, 3).flatten(-3, -2)  # (B, num_heads, region_h, region_w, C)
    return x, region_h, region_h

def _seq2grid(x: torch.Tensor, region_h: int, region_w: int, region_size: Tuple[int]):
    B, nhead, _, _, C = x.size()
    x = x.view(B, nhead, region_h, region_w, C // nhead).transpose(-1, -2). \
        contiguous().view(B, nhead, C // nhead, region_h * region_w)
    x = torch.einsum('bmhwpqd->bmdhpwq', x)
    return x

# Example usage
dim = 128
num_heads = 8
n_win = 7
qk_scale = None
topk = 4
side_dwconv = 3
auto_pad = False
attn_backend = 'torch'

model = BiLevelRoutingAttention(dim, num_heads, n_win, qk_scale, topk, side_dwconv, auto_pad, attn_backend)
input_data = torch.randn(2, 100, dim)  # Example input data with shape (batch_size, sequence_length, features)
output = model(input_data)
print(output.shape)  # Check the output shape
